import express from "express";
import { } from "../controllers/userController";

const userRouter = express.Router();



export default userRouter;