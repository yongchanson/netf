const API_KEY = 'api_key=1cf50e6248dc270629e802686245c2c8&language=ko';
const BASE_URL = 'https://api.themoviedb.org/3';
const API_URL = BASE_URL + '/discover/movie?sort_by=popularity.desc&'+API_KEY;
const IMG_URL = 'https://image.tmdb.org/t/p/w500';
const searchURL = BASE_URL + '/search/movie?'+API_KEY;

const original_img_url = "https://image.tmdb.org/t/p/original";
const movie_detail_http = BASE_URL + '/movie';
const movie_person_http = BASE_URL + '/person';

let movie_actor = location.pathname;
let movie_id = location.pathname;
let moviedetail = movie_detail_http + movie_id + "?" +API_KEY;
let moviesimilar = movie_detail_http + movie_id + "/similar?" +API_KEY;
let movieperson = movie_person_http + movie_person + "?" + API_KEY;
// 11.30
// let trend_url = BASE_URL + "/trending/movie/week?" + API_KEY;

// ?? query가 뭔지 모르겠다
let abdb = 'https://api.themoviedb.org/3/search/person?api_key=1cf50e6248dc270629e802686245c2c8&language=ko-KR&query=a&page=1&include_adult=false';